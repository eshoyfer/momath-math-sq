System.register(["github:frankwallis/plugin-typescript@7.0.6/plugin"], function($__export) {
  return {  setters: [function(m) { for (var p in m) $__export(p, m[p]); }],  execute: function() {}  };
});