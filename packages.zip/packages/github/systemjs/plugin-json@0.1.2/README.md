plugin-json
===========

JSON loader plugin

