/* */ 
module.exports = require('./interopRequireWildcard');
