/* */ 
module.exports = require('./typeof');
