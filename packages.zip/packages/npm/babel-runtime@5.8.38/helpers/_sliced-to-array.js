/* */ 
module.exports = require('./slicedToArray');
