/* */ 
module.exports = { "default": require("core-js/library/fn/object/entries"), __esModule: true };