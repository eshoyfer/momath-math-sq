/* */ 
module.exports = { "default": require("core-js/library/fn/object/is-extensible"), __esModule: true };