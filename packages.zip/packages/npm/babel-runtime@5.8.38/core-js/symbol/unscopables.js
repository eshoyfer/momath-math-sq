/* */ 
module.exports = { "default": require("core-js/library/fn/symbol/unscopables"), __esModule: true };