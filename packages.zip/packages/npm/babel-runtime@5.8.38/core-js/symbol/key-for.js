/* */ 
module.exports = { "default": require("core-js/library/fn/symbol/key-for"), __esModule: true };