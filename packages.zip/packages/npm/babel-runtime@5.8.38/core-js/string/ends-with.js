/* */ 
module.exports = { "default": require("core-js/library/fn/string/ends-with"), __esModule: true };