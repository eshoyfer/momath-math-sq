/* */ 
module.exports = { "default": require("core-js/library/fn/string/code-point-at"), __esModule: true };