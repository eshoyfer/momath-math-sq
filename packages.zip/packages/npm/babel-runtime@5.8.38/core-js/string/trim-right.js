/* */ 
module.exports = { "default": require("core-js/library/fn/string/trim-right"), __esModule: true };