/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/delete-metadata"), __esModule: true };