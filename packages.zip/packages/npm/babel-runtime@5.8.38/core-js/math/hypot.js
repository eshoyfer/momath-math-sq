/* */ 
module.exports = { "default": require("core-js/library/fn/math/hypot"), __esModule: true };