/* */ 
var html = require('fs').readFileSync(__dirname + '/robot.html', 'utf8');
console.log(html);
