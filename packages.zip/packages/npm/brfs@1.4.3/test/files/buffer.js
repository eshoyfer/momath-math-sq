/* */ 
var fs = require('fs');
var txt = fs.readFileSync(__dirname + '/robot.html');
console.log(txt);
